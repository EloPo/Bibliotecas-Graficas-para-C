This folder contains user contributions. Contributions are _not_ supported by the Box2D project.

Contributions may not compile or function correctly.